// Written in part by gemini

async function graphqlRequest(query, variables = {}, method = 'POST') {
    try {
        const response = await fetch('/graphql', {
            method: method,
            headers: {
                'Content-Type': 'application/json',
                'credentials': 'include',
            },
            body: JSON.stringify({
                query: query,
                variables: variables,
            }),
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const result = await response.json();
        return result;
    } catch (error) {
        console.error('Error in GraphQL request:', error);
        return null;
    }
}

async function signupUser(email) {
    const query = `
        mutation SignupUser($data: UserLoginInput!) {
            signupUser(data: $data) {
                id
                email
            }
        }
    `;

    const variables = {
        data: {
            email: email,
        },
    };

    const result = await graphqlRequest(query, variables);
    return result;
}

async function getUserEmail() {
    const query = `
        query GetUserFromCookie {
            getUserFromCookie {
                email
            }
        }
    `;

    const result = await graphqlRequest(query, {});
    const user = result.data.getUserFromCookie;

    if (user) {
        return user.email;
    } else {
        return null;
    }
}


async function getAllPublicPosts() {
    const query = `
        query AllPublicPosts {
            allPublicPosts {
                title
                body
                comments
                user {
                    email
                }
            }
        }
    `;

    const result = await graphqlRequest(query, {});
    return result.data;
}
async function postComment(blogPostTitle, commentBody) {
    const mutation = `
        mutation CreateBlogComment($data: CreateCommentInput!) {
            createBlogComment(data: $data) {
                title
                body
                comments
                user {
                    email
                }
            }
        }
    `;

    const variables = {
        data: {
            blogPostTitle: blogPostTitle,
            body: commentBody,
        },
    };

    const result = await graphqlRequest(mutation, variables);
    return result;
}

async function createBlogPost(isPrivate, title, body) {
    const mutation = `
        mutation CreateBlogPost($data: CreateBlogPostInput!) {
            createBlogPost(data: $data) {
                title
                body
                isPrivate
                comments
                user {
                    email
                }
            }
        }
    `;

    const variables = {
        data: {
            isPrivate: isPrivate,
            title: title,
            body: body,
        },
    };

    const result = await graphqlRequest(mutation, variables);
    return result;
}