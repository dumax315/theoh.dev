const blogPostTemplate = document.getElementById("blogPostTemplate");
const commentTemplate = document.getElementById("commentTemplate");

const createBlogPostElement = (post) => {
    const newPost = blogPostTemplate.content.cloneNode(true);
    const titleElm = newPost.querySelector("h3");
    titleElm.innerText = post.title;
    const bodyElm = newPost.querySelectorAll("p");
    bodyElm[0].innerText = post.body;
    bodyElm[1].innerText = "posted by: " + post.user.email;
    const commentsElm = newPost.querySelector("ul");
    for (const comment of post.comments) {
        const commentElm = commentTemplate.content.cloneNode(true);
        commentElm.querySelector("p").innerText = comment;
        commentsElm.appendChild(commentElm)
    }
    newPost.querySelector(".comment-form").addEventListener("submit", (event) => {
        event.preventDefault();
        submitCommentForm(post.title, event, titleElm);
    })
    return newPost;
}

getAllPublicPosts().then(posts => {
    const publicPostsContainer = document.getElementById("public-posts-contianer");
    for (const post of posts.allPublicPosts) {
        publicPostsContainer.appendChild(createBlogPostElement(post));
    }
});

getUserEmail().then(email => {
    setEmail(email)
})

const setEmail = (email) => {
    if (email) {
        document.getElementById("email-box").innerText = email;
        for(const element of document.getElementsByClassName("signed-out-visible")) {
            element.classList.add("invisible");
        }
        for(const element of document.getElementsByClassName("signed-in-visible")) {
            element.classList.remove("invisible");
        }
    } else {
        document.getElementById("email-box").innerText = email;
        for(const element of document.getElementsByClassName("signed-in-visible")) {
            element.classList.add("invisible");
        }
        for(const element of document.getElementsByClassName("signed-out-visible")) {
            element.classList.remove("invisible");
        }
    }
}

const signupForm = document.getElementById("signup");

signupForm.addEventListener("submit", (event) => {
    event.preventDefault();
    submitSignupForm();
});

const submitSignupForm = async () => {
    const emailInput = document.getElementById("email-input");
    if(emailInput.value == undefined || emailInput.value.length < 1) {
        alert("please enter email to sign up");
        return;
    }
    const {data} = await signupUser(emailInput.value);
    
    setEmail(data.signupUser.email)
}

const signout = () => {
    document.cookie = "token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";;
    location.reload();
}

const postForm = document.getElementById("postNewBlogPost");

postForm.addEventListener("submit", (event) => {
    event.preventDefault();
    submitPostForm();
});

const submitPostForm = async () => {
    const titleInput = document.getElementById("newBlogTitle").value;
    const bodyInput = document.getElementById("newBlogBody").value;
    const isPrivateInput = document.getElementById("newBlogIsPrivate").value;

    const {data, errors} = await createBlogPost(isPrivateInput == "private", titleInput, bodyInput);
    
    if (data) {
        let targetContainer = document.getElementById("public-posts-contianer");
        if (data.createBlogPost.isPrivate) {
            targetContainer = document.getElementById("private-posts-contianer");
        }
        targetContainer.appendChild(createBlogPostElement(data.createBlogPost));
        targetContainer.lastElementChild.scrollIntoView({ behavior: "smooth", block: "end", inline: "nearest" });
    } else {
        alert(errors[0].message);
    }
}

const submitCommentForm = async (postTitle, event, oldPostTitleElm) => {
    const form = event.target;
    const bodyInput = form.querySelector(".body").value;

    const {data, errors} = await postComment(postTitle, bodyInput);
    
    if (data) {
        oldPostTitleElm.parentNode.replaceWith(createBlogPostElement(data.createBlogComment));
    } else {
        alert(errors[0].message);
    }
}