import "reflect-metadata";
import {
    Arg,
    Ctx,
    Field,
    FieldResolver,
    ID,
    InputType,
    Mutation,
    ObjectType,
    Query,
    Resolver,
    Root,
} from "type-graphql";
import { randomUUID } from "crypto";
import { Context} from ".";
import { GraphQLError } from "graphql";
import 'dotenv/config'

@ObjectType()
export class User {
  @Field((type) => ID)
  id: string

  @Field()
  email: string

  allBlogPosts: BlogPost[]
}

@ObjectType()
export class BlogPost {
    @Field()
    isPrivate: boolean

    @Field()
    title: string

    @Field()
    body: string

    @Field((type) => [String])
    comments: string[]

    @Field(type => User)
    user: User
}

@InputType()
class UserLoginInput {
    @Field()
    email: string;
}

@InputType()
class CreateBlogPostInput {
    @Field()
    isPrivate: boolean

    @Field()
    title: string

    @Field()
    body: string
}

@InputType()
class CreateCommentInput {
    @Field()
    blogPostTitle: string

    @Field()
    body: string
}

type DB = { [key: string]: User};

const users: DB = {};

seedDB(users);


@Resolver(User)
export class UserResolver {
    @Mutation((returns) => User)
    async signupUser(
        @Arg("data") data: UserLoginInput,
        @Ctx() ctx: Context
    ): Promise<User> {
        const accessToken = randomUUID();

        ctx.res.setHeader("Set-Cookie",`token=${accessToken}; SameSite=None; Secure; Max-Age=10000`);

        users[accessToken] = {
            email: data.email,
            allBlogPosts: [],
            id: "user_"+Object.keys(users).length,
        }

        return users[accessToken];
    }

    @Query(() => [BlogPost])
    async allPublicPosts(@Ctx() ctx: Context) {
        const publicBlogPosts = [];
        for(const user of Object.values(users)) {
            for(const blogPost of user.allBlogPosts) {
                if(!blogPost.isPrivate) {
                    publicBlogPosts.push(blogPost)
                }
            }
        }
        return publicBlogPosts;
    }

    @Query(() => User, { nullable: true })
    async getUserFromCookie(@Ctx() ctx: Context) {
        const token = getCookie(ctx.cookies, "token");
        if (!token) {
            return null;
        }
        return users[token]
    }

    @Mutation((returns) => BlogPost)
    async createBlogComment(
        @Arg("data") data: CreateCommentInput,
        @Ctx() ctx: Context
    ): Promise<BlogPost> {
        const token = getCookie(ctx.cookies, "token");
        if(!token || ! (token in users)) {
            throw new GraphQLError(
                "Sign up to comment",
                {
                    extensions: {
                        code: "FORBIDDEN",
                    },
                }
            );
        }
        for(const user of Object.values(users)) {
            for(const blogPost of user.allBlogPosts) {
                if(blogPost.title == data.blogPostTitle) {
                    blogPost.comments.push(data.body);
                    return blogPost;
                }
            }
        }
        throw new GraphQLError(
            "Couldn't find matching blog post",
            {
                extensions: {
                    code: "FORBIDDEN",
                },
            }
        );
    }

    @Mutation((returns) => BlogPost)
    async createBlogPost(
        @Arg("data") data: CreateBlogPostInput,
        @Ctx() ctx: Context
    ): Promise<BlogPost> {
        const token = getCookie(ctx.cookies, "token");
        if(!token || ! (token in users)) {
            throw new GraphQLError(
                "You are not authorized to perform this action.",
                {
                    extensions: {
                        code: "FORBIDDEN",
                    },
                }
            );
        }
        for(const user of Object.values(users)) {
            for(const blogPost of user.allBlogPosts) {
                if(blogPost.title == data.title) {
                    throw new GraphQLError(
                        "No repeat blog post titles please!",
                        {
                            extensions: {
                                code: "FORBIDDEN",
                            },
                        }
                    );
                }
            }
        }
        const user = users[token];
        const blogPostIndex = user.allBlogPosts.push({
            title: data.title,
            body: data.body,
            isPrivate: data.isPrivate,
            comments: [],
            user: user,
        })
        return user.allBlogPosts[blogPostIndex-1];
    }

    @FieldResolver((returns) => [BlogPost])
    publicBlogPosts(@Root() user: User): BlogPost[] {
        const publicPosts = [];
        for(const post of user.allBlogPosts) {
            if(!post.isPrivate){
                publicPosts.push(post);
            }
        }
        return publicPosts;
    }

    @FieldResolver((returns) => [BlogPost], {nullable: true})
    privateBlogPosts(@Root() user: User): BlogPost[] {
        const privatePosts = [];
        for(const post of user.allBlogPosts) {
            if(post.isPrivate){
                privatePosts.push(post);
            }
        }
        return privatePosts;
    }
}

function seedDB(users: DB){
    const admin_1_token = crypto.randomUUID();
    users[admin_1_token] = {
        id: "admin_1",
        email: "admin1@admin.com",
        allBlogPosts: []
    }
    users[admin_1_token].allBlogPosts.push({
        title: "I love posting on my blog",
        body: "I hope y'all like posting too",
        comments: ["theo was here :P"],
        isPrivate: false,
        user: users[admin_1_token]
    })

    users[admin_1_token].allBlogPosts.push({
        title: "Wait, are you sure my secrets are even private?",
        body: "Well, I couldn't see admin0's secrets so...",
        comments: [],
        isPrivate: false,
        user: users[admin_1_token]
    })

    users[admin_1_token].allBlogPosts.push({
        title: "flag_part_1",
        body: process.env.FLAG_PART_1 ?? "flag{",
        comments: [],
        isPrivate: true,
        user: users[admin_1_token]
    })

    const admin_2_token = crypto.randomUUID();
    users[admin_2_token] = {
        id: "admin_2",
        email: "admin2@admin.com",
        allBlogPosts: []
    }
    users[admin_2_token].allBlogPosts.push({
        title: "flag_part_2",
        body: process.env.FLAG_PART_2 ?? "}",
        comments: [],
        isPrivate: true,
        user: users[admin_2_token]
    })
}

function getCookie(cookie_string: string | undefined, name: string): string | null {
    if (!cookie_string) return null;
    const cookies = cookie_string.split(" ")
    for (let i = 0; i < cookies.length; i++) {
        let cookiePair = cookies[i];
        while (cookiePair.startsWith(' ')) {
            cookiePair = cookiePair.substring(1);
        }
        const parts = cookiePair.split('=');
        const cookieName = decodeURIComponent(parts[0]);
        if (cookieName === name) {
            const cookieValue = parts[1];
            return cookieValue;
        }
    }
    return null;
}
