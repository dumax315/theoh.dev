import "dotenv/config.js";
import { ApolloServer } from "@apollo/server";
import { UserResolver } from "./user.js";
import { buildSchema } from "type-graphql";
import { expressMiddleware } from "@apollo/server/express4";
import { ApolloServerPluginDrainHttpServer } from "@apollo/server/plugin/drainHttpServer";
import express from "express";
import http from "http";
import cors from "cors";

export interface Context {
    cookies: string;
    res: express.Response;
}

const PORT = parseInt(process.env.PORT ?? "4000");

const app = express();
const httpServer = http.createServer(app);

async function bootstrap() {
    const schema = await buildSchema({
        resolvers: [UserResolver],
        emitSchemaFile: "./src/schema.graphql",
    });

    const server = new ApolloServer({
        schema,
        plugins: [ApolloServerPluginDrainHttpServer({ httpServer })],
        // allows for tools like https://studio.apollographql.com/sandbox/explorer to work
        introspection: true,
    });

    await server.start();

    app.use(
        "/graphql",
        cors<cors.CorsRequest>(),
        express.json({ limit: "50mb" }),
        expressMiddleware(server, {
            context: async ({ req, res }) => ({
                cookies: req.headers.cookie,
                res: res,
            }),
        })
    );

    app.use(express.static('static'))

    await new Promise<void>((resolve) =>
        httpServer.listen({ port: PORT }, resolve)
    );
    console.log(`Website ready at http://localhost:4000/`);
}

bootstrap();
