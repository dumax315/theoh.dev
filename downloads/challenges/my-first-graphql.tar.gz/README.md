# Awesome Graphql Blog — WRECKCTF 2025

A web challenge by Theo Halpern.

I hear the admins have a secret relationship, what might they be hiding in their private blog posts?

## Run locally

Install Docker, then run these commands from the extracted folder:

    docker build -t theo-graphql-blog ./server
    docker run --rm --name theo-graphql-blog --memory=256m --cpus=0.5 --pids-limit=128 -p 127.0.0.1:4000:4000 theo-graphql-blog

Open http://localhost:4000. Send GraphQL requests to http://localhost:4000/graphql.
Stop with Ctrl+C; running the container again resets all posts, comments, and users.
The bundled .env contains local placeholder flag parts, not the competition flag.

This application is intentionally vulnerable. Keep it on localhost and use dummy data.
Do not publish it to the internet or deploy it alongside personal services.
